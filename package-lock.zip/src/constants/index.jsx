const homeIcon = require("../assets/images/pokemon.png");
const homeLogo = require("../assets/images/homeLogo.png");
const catchPokemon = require("../assets/images/catch.png");
const background = require("../assets/images/background.jpg");

export default { homeIcon, homeLogo, catchPokemon, background };
