/** @jsxRuntime classic */
/** @jsx jsx */

import { jsx } from "@emotion/react";
import { useParams } from "react-router-dom";
import React, { useContext, useState, useEffect } from "react";
import { useQuery } from "@apollo/client";
import { Context as PokemonContext } from "../../context/PokemonContext";
import { Link } from "react-router-dom";
import { useHistory } from "react-router";

import * as style from "./style";
import * as GET_POKEMONS from "../../api/get-pokemon-profile";
import * as images from "../../constants/index";

const CatchPokemonPage = () => {
  let history = useHistory();
  const { name } = useParams();
  const { savePokemon, tempPokemonData, checkStatus, checkName } =
    useContext(PokemonContext);
  const [userName, setUserName] = useState("");
  const [checkNameTemp, setcheckNameTemp] = useState(checkName);

  useEffect(() => {
    setcheckNameTemp(checkName);
  }, [checkName]);

  const onSaveBtn = (e) => {
    console.log(checkNameTemp);
    e.preventDefault();
    savePokemon(tempPokemonData.name, userName, tempPokemonData.caughtImg);
    saveNameResult();
  };

  const onReleaseBtn = (e) => {
    e.preventDefault();
    if (window.confirm("Are you sure you want to released the Pokemon?")) {
      history.push("/pokemonlist");
    }
  };

  const saveNameResult = () => {
    console.log(checkNameTemp);
    if (checkNameTemp) {
      alert("Nama Sudah Ada");
    } else {
      if (window.confirm("Are you sure you want to save the Pokemon?")) {
        history.push("/mypokemonlist");
      }
    }
  };

  return (
    <div className="container">
      {checkStatus === 1 ? (
        <div css={style.container}>
          <div css={style.cardContainer}>
            <form>
              <div css={style.card}>
                <h1>{tempPokemonData.name + checkNameTemp}</h1>
                <img
                  src={tempPokemonData.caughtImg}
                  alt="Pokemon Image"
                  css={style.pokemonImage}
                />
                <h2 css={style.title}>
                  Congratulations Pokemon <br /> have been caught
                </h2>
                <input
                  type="text"
                  onChange={(e) => {
                    setUserName(e.target.value);
                  }}
                  value={userName}
                  css={style.input}
                  placeholder="Enter name of the pokemon"
                  required
                />

                {userName === "" ? (
                  <Link to="/mypokemonlist">
                    <button
                      disabled
                      onClick={onSaveBtn}
                      css={style.saveBtnDisabled}
                    >
                      Save Pokemon
                    </button>
                  </Link>
                ) : (
                  <button onClick={onSaveBtn} css={style.saveBtn}>
                    Save Pokemon
                  </button>
                )}

                <button
                  type="submit"
                  onClick={onReleaseBtn}
                  css={style.releaseBtn}
                >
                  Release Pokemon
                </button>
              </div>
            </form>
          </div>
        </div>
      ) : (
        <div css={style.container}>
          <div css={style.containerTwo}>
            <img src="" alt="" />
            <div css={style.rowTwo}>
              <h1 css={style.titleTwo}>Pokemon Failed to Catch</h1>
              <img
                css={style.pokemonImageTwo}
                src={tempPokemonData.uncaughtImg}
                alt="Uncaught Pokemon"
              />
              <h2>{tempPokemonData.name} has run away</h2>
              <h2>Try again later!!!</h2>

              <Link to={`/pokemondetail/${name}`}>
                <button css={style.saveBtn}>Catch Again</button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CatchPokemonPage;
