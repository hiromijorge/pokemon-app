/** @jsxRuntime classic */
/** @jsx jsx */

import { useEffect, useState } from "react";
import { useQuery } from "@apollo/client";
import { jsx } from "@emotion/react";
import * as GET_POKEMONS from "../../api/get-pokemon";
import * as style from "./style";
import { Link } from "react-router-dom";

const MyPokemonListPage = () => {
  const [page, setPage] = useState(0);
  const [offset, setOffset] = useState(20);

  const gqlVariables = {
    offset: offset,
  };
  const handleBtnPress = (id) => {
    if (id === "next") {
      setPage(page + 1);
      setOffset(offset + 20);
    } else if (id === "prev") {
      setPage(page - 1);
      setOffset(offset - 20);
    }
  };

  useEffect(() => {
    console.log("page is changes");
  }, [page]);

  const { loading, error, data } = useQuery(GET_POKEMONS.getAllPokemon_Query, {
    variables: gqlVariables,
  });

  if (loading) return null;
  if (error) return `Error! ${error.message}`;
  console.log(data.pokemons.results);
  return (
    <div className="base" css={style.base}>
      <div className="container" css={style.container}>
        <div className="row" css={style.row}>
          {data.pokemons.results.map((pokemon) => (
            <Link
              to={`/pokemondetail/${pokemon.name}`}
              css={style.link}
              key={pokemon.id}
            >
              <div className="col-4" css={style.col4} key={pokemon.name}>
                <img src={pokemon.image} alt="" css={style.img} />
                <p css={style.name}>{pokemon.name}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
      <div className="button" css={style.btnContainer}>
        <div className="button-prev" css={style.btnInnerContainer}>
          {page === 0 ? (
            <button
              disabled
              onClick={() => handleBtnPress("prev")}
              css={style.btnDisabled}
            >
              &#8249;
            </button>
          ) : (
            <button onClick={() => handleBtnPress("prev")} css={style.btn}>
              &#8249;
            </button>
          )}
        </div>
        <p>{page}</p>
        <div className="button-next" css={style.btnInnerContainer}>
          <button onClick={() => handleBtnPress("next")} css={style.btn}>
            &#8250;
          </button>
        </div>
      </div>
    </div>
  );
};

export default MyPokemonListPage;
