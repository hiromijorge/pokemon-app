/** @jsxRuntime classic */
/** @jsx jsx */

import { useContext } from "react";
import { jsx } from "@emotion/react";
import * as style from "./style";
import { Context as PokemonContext } from "../../context/PokemonContext";

const MyPokemonListPage = () => {
  const { state } = useContext(PokemonContext);

  console.log(state);
  return (
    <div className="container" css={style.container}>
      <div className="row" css={style.row}>
        {state.map((item) => (
          <div className="col" css={style.col}>
            <p>Pokemon Name {item.pokemonName}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MyPokemonListPage;
