import { css } from "@emotion/react";

export const container = css`
  max-width: 100%;
  height: 1000px;
  background: radial-gradient(#fff, #ef6079ff);
`;

export const row = css`
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
`;

export const col = css`
  flex-basis: 25%;
`;

export const box = css`
  width: 200px;
  height: 200px;
  background: blue;
`;
