import { css } from "@emotion/react";

export const base = css`
  background: radial-gradient(#fff, #ffd6d6);
`;

export const container = css`
  max-width: 1300px;
  width: 100%;
  margin: auto;
`;

export const navbar = css`
  display: flex;
  align-items: center;
  padding-top: 15px;
  margin-right: 10px;
  margin-left: 10px;
  padding-bottom: 15px;
`;

export const homeLogo = css`
  height: 8vh;
  width: 8hh;
`;

export const navigationLink = css`
  flex: 1;
  text-align: right;
`;

export const link = css`
  text-decoration: none;
  margin: 10px;
  padding: 5px;
  font-size: 18px;
  color: #555;
`;
