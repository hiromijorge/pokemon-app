/** @jsxRuntime classic */
/** @jsx jsx */
import { Link } from "react-router-dom";
import { jsx } from "@emotion/react";

import * as style from "./style";
import images from "../../constants/index";

const Navbar = () => {
  const { homeIcon } = images;
  return (
    <div className="base" css={style.base}>
      <div className="container" css={style.container}>
        <div className="navbar" css={style.navbar}>
          <img src={homeIcon.default} alt="Pokemon Logo" css={style.homeLogo} />
          <nav css={style.navigationLink}>
            <div className="links">
              <Link css={style.link} to="/">
                Home
              </Link>
              <Link css={style.link} to="/">
                Pokemon List
              </Link>
            </div>
          </nav>
        </div>
      </div>
    </div>
    // <nav className="navbar" style={style.base}>
    //   <h1>Pokemon Hunter</h1>
    //   <div className="links">
    //     <Link to="/">Home</Link>
    //     <Link to="/pokemonlist">Pokemon List</Link>
    //   </div>
    // </nav>
  );
};

export default Navbar;
