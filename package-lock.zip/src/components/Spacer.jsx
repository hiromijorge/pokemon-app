const Spacer = ({ children }) => {
  return <div style={{ marginTop: 20, marginBottom: 20 }}>{children}</div>;
};

export default Spacer;
