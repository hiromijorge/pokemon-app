import { css } from "@emotion/react";

export const base = css`
  background: radial-gradient(#fff, #ffd6d6);
`;

export const container = css`
  max-width: 1300px;
  width: 100%;
  margin: auto;
`;

export const row = css`
  display: flex;
  justify-content: space-around;
  align-items: center;
  flex-wrap: wrap;
`;

export const col = css`
  flex-basis: 50%;
  padding: 20px;
`;

export const h2 = css`
  font-size: 50px;
  line-height: 60px;
`;

export const img = css`
  width: 100%;
`;

export const button = css`
  display: inline-block;
  background-color: #ff523b;
  color: #fff;
  padding: 8px 30px;
  margin: 0px 0;
  border-radius: 30px;
  transition: background 0.5s;
  &:hover {
    background: #563434;
  }
  text-decoration: none;
`;
